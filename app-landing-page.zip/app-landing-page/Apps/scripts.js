// FAQ Accordion
document.querySelectorAll('.accordion-item h3').forEach(item => {
    item.addEventListener('click', () => {
        item.nextElementSibling.classList.toggle('active');
    });
});
